﻿@echo off
chcp 65001 > nul
title SensTalk PC Engine
echo ========================================================
echo        SensTalk PC Engine (센스톡 PC 로컬 엔진 v5.0)
echo ========================================================
echo.
echo [*] 센스톡 PC 전송 엔진을 시작합니다... (포트 28888)
python sensebot.py
if %ERRORLEVEL% NEQ 0 (
    echo.
    echo [오류] Python 실행 중 오류가 발생했습니다.
    echo Python 3.9 이상이 설치되어 있는지 확인해주세요.
    pause
)