@echo off
chcp 65001 > nul
title SensTalk PC Engine v2.4

echo ========================================================
echo        SensTalk PC Engine v2.4 Launcher
echo ========================================================
echo.

set "SCRIPT_DIR=%~dp0"

where python >nul 2>nul
if %ERRORLEVEL% NEQ 0 (
    echo [오류] Python이 설치되어 있지 않거나 환경변수 PATH에 등록되지 않았습니다.
    echo https://www.python.org 에서 Python 3를 설치할 때
    echo "Add Python to PATH" 체크박스를 반드시 체크해주세요.
    echo.
    pause
    exit /b 1
)

if exist "%SCRIPT_DIR%sensebot.py" (
    echo [*] 센스톡 PC 엔진 v2.4 가동 중... (포트 28888)
    cd /d "%SCRIPT_DIR%"
    python sensebot.py
    pause
    exit /b 0
)

echo [Error] Cannot find sensebot.py
pause
